# Demo Playwright

1) Create Python venv
2) Install Playwright `pip install pytest-playwright`
3) Install browsers `playwright install`

## Playwright Debug Mode

Command below allows to go through test step by step:
`PWDEBUG=1 pytest -s -k <name of method (not a file!)>`

Next command allows to save a result of run in specific file with manager:
`pytest --tracing=retain-on-failure`
`playwright show-trace trace.zip`
